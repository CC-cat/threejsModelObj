
$(document).ready(function(){
	
	$("#myCar").vc3dEye({
		imagePath:"images/",
		totalImages:51,
		imageExtension:"png"
	});
	
});

